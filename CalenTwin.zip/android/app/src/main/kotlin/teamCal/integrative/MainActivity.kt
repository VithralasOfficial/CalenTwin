package teamCal.integrative

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
